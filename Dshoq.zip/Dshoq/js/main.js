
(function($){
	'use strict';

	jQuery(document).ready(function(){

		var pImg = $ ('.p-img').height();
		console.log(pImg);

	});

})(jQuery);

